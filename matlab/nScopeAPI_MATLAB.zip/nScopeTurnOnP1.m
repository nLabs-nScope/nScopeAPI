function nScopeTurnOnP1( frequency, duty )
%nScopeTurnOnA1( frequency, iSunipolar, amplitude )
%
%   Turn on the A1 output of nScope
%
%   frequency: the frequency of the pulse in Hz
%   duty: duty percentage of the pulse
%
%   nScope must have a connection open before running
%   run nScopeAPI('open',1) to open


nScopeAPI('setP1frequencyInHz',frequency);      %Set the frequency of P1
nScopeAPI('setP1dutyPercentage',duty);          %Set the P1 duty percentage
nScopeAPI('setP1on',1);                         %Set P1 on


end

